

exports.main = async function (event, context) {
    return {
        statusCode: 200,
        body: 'Request taked by Lambda'
    }
}